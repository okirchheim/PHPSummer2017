<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        // put your code here
        
        /*
         * http://php.net/manual/en/ref.filesystem.php
         * http://php.net/manual/en/ref.dir.php
         * http://php.net/manual/en/book.filesystem.php
         * http://php.net/manual/en/class.directoryiterator.php
         * 
         */
        
        
        ?>
    </body>
</html>
