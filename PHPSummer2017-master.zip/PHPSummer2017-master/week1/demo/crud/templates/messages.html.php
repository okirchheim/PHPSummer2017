<?php if ( isset($message) && strlen($message) ) : ?>
<p class="alert alert-success"><?php echo $message; ?></p>
<?php endif; ?>
