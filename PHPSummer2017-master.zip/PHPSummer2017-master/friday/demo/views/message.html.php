<?php if ( isset($message) ) : ?>
<p class="bg-success"><?php echo $message; ?></p>
<?php endif; ?>
