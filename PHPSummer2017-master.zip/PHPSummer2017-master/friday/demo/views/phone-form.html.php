<br />

<div class="container">
    <h1>Add Phone</h1>
    <form action="#" method="post">   
       Phone: <input name="phone" value="<?php echo $phone; ?>" /> <br />
       Phone Type: <input name="phonetype" value="<?php echo $phoneType; ?>" /> <br />
       <input type="submit" value="submit" class="btn btn-primary" />
    </form>
</div>