/* Recommend Style: https://github.com/johnpapa/angular-styleguide */
'use strict';
angular.module('app.widgets', []);