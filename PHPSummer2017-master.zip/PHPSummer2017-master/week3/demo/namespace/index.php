<?php 
namespace week3\gforti;

include './bootstrap.php'; ?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        
                        
            $util = new Util();            
            $scope = new Scope();
        
        ?>
    </body>
</html>
