<?php

/**
 * Description of DBException
 *
 * @author GFORTI
 * 
 * We extend the Exception class that is built into PHP to create our own Exceptions.
 * 
 */
class DBException extends Exception { }